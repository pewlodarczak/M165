import React, { useEffect, useState } from 'react';
import { functions } from './appwrite'; // Importiere die initialisierten Dienste

function App() {
  const [cars, setCars] = useState([]);
  const [loading, setLoading] = useState(true);

const loadFerraris = async () => {
    try {
      const execution = await functions.createExecution(
        '69be90a200394182f3c3',
        '',
        false,
        '/',
        'GET'
      ); // <--- Prüfe, ob hier das Semikolon oder die Klammer korrekt ist

      const data = JSON.parse(execution.responseBody);
      setCars(data.cars);
    } catch (error) { // <--- Zeile 21: Hier hakt es, wenn oben eine } fehlt!
      console.error("Fehler beim Laden:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadFerraris();
  }, []);

  if (loading) return <div>Lade Ferraris...</div>;

  return (
    <div className="App">
      <h1>DriveGram - Ferrari Feed</h1>
      <div className="grid">
        {cars.map((car, index) => (
          <div key={index} className="car-card">
            <img src={car.image_url} alt={car.title} style={{width: '300px'}} />
            <h3>{car.brand} {car.model}</h3>
            <p>{car.title}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;